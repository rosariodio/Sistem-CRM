<?php
include 'koneksi.php';

session_start(); // Start session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the registration form
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';

    // Check if the username already exists
    $check_query = "SELECT id_user FROM user WHERE username=?";
    $check_stmt = $koneksi->prepare($check_query);
    $check_stmt->bind_param('s', $username);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows == 0) {
        // If the username doesn't exist, insert the new user into the database
        $insert_query = "INSERT INTO user (username, password, email, role) VALUES (?, ?, ?, 1)";
        $insert_stmt = $koneksi->prepare($insert_query);
        $insert_stmt->bind_param('sss', $username, $password, $email);

        if ($insert_stmt->execute()) {
            // Successful registration, redirect to login page
            echo "Registration successful. Redirecting to login page...";
            header("Refresh: 2; URL=http://localhost/sistem_loyalty/index.php");
        } else {
            // Handle query failure
            echo "Error: Could not register user. Please try again.";
        }

        $insert_stmt->close();
    } else {
        // If username already exists, show error message
        echo "Username already exists. Please choose a different username.";
    }

    $check_stmt->close();
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap');

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Source Sans Pro', Arial, sans-serif; /* Odoo font style */
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
        }

        .container {
            background-color: #ffffff;
            padding: 25px 35px;
            border: 1px solid #d1d1d1;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .container p:first-of-type {
            font-size: 28px;
            font-weight: 600; /* Semi-bold */
            color: #c0392b; /* Red primary color */
            margin: 0 0 10px;
        }

        .container p:nth-of-type(2) {
            font-size: 16px;
            font-weight: 400; /* Regular weight */
            color: #7f8c8d; /* Subtle grey */
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #d1d1d1;
            border-radius: 4px;
            font-size: 14px;
            font-family: 'Source Sans Pro', Arial, sans-serif;
        }

        input[type="submit"] {
            background-color: #c0392b; /* Red primary color */
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-family: 'Source Sans Pro', Arial, sans-serif;
        }

        input[type="submit"]:hover {
            background-color: #e74c3c; /* Hover effect */
        }

        #login {
            cursor: pointer;
            color: #c0392b; /* Red primary color */
            font-size: 14px;
            font-weight: 600;
            display: inline-block;
            margin-top: 10px;
        }

        #login:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <p>Register</p>
        <p>Sistem Loyalty</p>
        <form method="POST">
            <label for="username">Username</label><br/>
            <input type="text" name="username" id="username" placeholder="Username" required><br/>
            <label for="email">Email</label><br/>
            <input type="email" name="email" id="email" placeholder="Email" required><br/>
            <label for="password">Password</label><br/>
            <input type="password" name="password" id="password" placeholder="Password" required><br/><br/>
            <input type="submit" name="submit" value="Register">
            <span id="login">Login</span> 
        </form>
    </div>
    <script>
        // Redirect to the login page when the "Login" text is clicked
        document.getElementById("login").addEventListener("click", function() {
            window.location.href = "http://localhost/sistem_loyalty/index.php";
        });
    </script>
</body>
</html>
