<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman CRM</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Source Sans Pro', sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            color: #fff;
        }

        .container {
            margin: 20px;
        }

        h2 {
            text-align: center;
            color: #fff; /* White text color */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            color: #333;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th {
            background-color: #F9F7C9;
            color: #B52A34; /* Red color theme */
            padding: 12px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        td {
            background-color: #fafafa;
        }

        a.button {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #B52A34; /* Red color theme */
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin: 5px 0;
        }

        a.button:hover {
            background-color: #D05B57; /* Lighter red on hover */
        }

        #overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9998;
        }

        #loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            text-align: center;
            color: white;
            font-size: 24px;
            padding-top: 20%;
        }
    </style>
    <script>
        function showLoading() {
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('loading').style.display = 'block';
        }
    </script>
</head>
<body>
<div id="overlay"></div>
<div id="loading">Processing your request, please wait...</div>
<div class="container">
    <h2>Halaman CRM</h2>
    <a href="http://localhost/sistem_loyalty/homePage.php" class="button">Back</a>
    <table>
        <tr>
            <th>Username</th>
            <th>Item</th>
            <th>Total Transaksi</th>
            <th>Poin Loyalty</th>
            <th>Action</th>
        </tr>
        <?php
        $query = "SELECT user.id_user, user.username, user.poin_loyalty, 
        GROUP_CONCAT(produk.nama_produk) AS purchased_items, 
        COUNT(ts.item) AS purchase_count, 
        SUM(produk.harga_produk_satuan * ts.qty) AS total_spending
        FROM user 
        JOIN transaksi_sales ts ON user.id_user = ts.user
        JOIN produk ON produk.id_produk = ts.item 
        GROUP BY user.id_user
        ORDER BY purchase_count DESC";
        $result = mysqli_query($koneksi, $query);

        if (!$result) {
            echo "query gagal!";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>" . htmlspecialchars($row['purchased_items']) . "</td>
                        <td>" . htmlspecialchars($row['total_spending']) . "</td>
                        <td>" . htmlspecialchars($row['poin_loyalty']) . " points</td>
                        <td>
                            <a href='http://localhost/sistem_loyalty/crm/send_mail.php?id_user=" . $row['id_user'] . "' class='button' onclick='showLoading()'>Mail</a>
                        </td>
                      </tr>";
            }
        }
        ?>
    </table>
</div>
</body>
</html>
