<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

$id = $_SESSION['id_user'];

// Fetch user role
$sql_role = "SELECT * FROM user WHERE id_user = ?";
$stmt_role = $koneksi->prepare($sql_role);
$stmt_role->bind_param("i", $id);
$stmt_role->execute();
$result_role = $stmt_role->get_result();
$user = $result_role->fetch_assoc();
$role_id = $user['role'];

// Fetch allowed features for the user role
$sql_access = "SELECT link FROM hak_akses WHERE role_id = ?";
$stmt_access = $koneksi->prepare($sql_access);
$stmt_access->bind_param("i", $role_id);
$stmt_access->execute();
$result_access = $stmt_access->get_result();

// Query to retrieve prize data from the 'hadiah' table
$query_produk = "SELECT id_produk, nama_produk, harga_produk_satuan FROM produk";
$result_produk = $koneksi->query($query_produk); // Execute the query

// Check if the query returned any results
if ($result_produk->num_rows == 0) {
    echo "No product available.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Shop</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
        }

        h1, h2, h3 {
            text-align: center;
            color: #fff; /* White color for the headings */
        }

        .button-container {
            text-align: center;
            margin: 20px 0;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #c0392b; /* Red color theme */
            color: white;
            border-radius: 5px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #e74c3c; /* Darker red on hover */
        }

        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* Auto grid, responsive */
            gap: 20px;
            padding: 20px;
            justify-items: center; /* Center items within each grid cell */
        }

        .product-card {
            background-color: #fff;
            border: 2px solid #c0392b; /* Red border for card */
            border-radius: 10px;
            padding: 20px;
            width: 100%; /* Ensures the card fits the grid cell */
            text-align: center;
            transition: transform 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Shadow effect */
        }

        .product-card:hover {
            transform: scale(1.05);
        }

        .product-card img {
            max-width: 100%; /* Make sure images don't overflow */
            height: auto;
            border-radius: 8px;
        }

        .product-card h3 {
            color: #c0392b;
            margin: 15px 0;
            font-size: 18px;
            font-weight: bold;
        }

        .product-card p {
            color: #555;
            margin: 10px 0;
        }

        .product-card .price {
            color: #c0392b;
            font-size: 20px;
            font-weight: 600;
        }

        .product-card a {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #c0392b; /* Red color theme */
            color: white;
            border-radius: 5px;
            font-weight: 600;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .product-card a:hover {
            background-color: #e74c3c; /* Darker red on hover */
        }
    </style>
</head>
<body>
    <div class="button-container">
	<h1>Product Shop</h1>
        <?php while($row = $result_access->fetch_assoc()): ?>
            <?php if($row['link'] === 'http://localhost/sistem_loyalty/data_produk/read.php'): ?>
                <a href='<?php echo $row['link']; ?>' class="button">Edit Product</a>
            <?php endif; ?>
        <?php endwhile; ?>
        <a href="http://localhost/sistem_loyalty/homePage.php" class="button">Back</a>
    </div>

    <!-- Product Grid -->
    <div class="product-grid">
        <?php while($row = $result_produk->fetch_assoc()): ?>
        <div class="product-card">
            <img src="product-image.jpg" alt="Product Image"> <!-- Placeholder for product image -->
            <h3><?php echo $row['nama_produk']; ?></h3>
            <p>Description of the product can go here.</p>
            <p class="price">Rp. <?php echo number_format($row['harga_produk_satuan'], 0, ',', '.'); ?></p>
            <a href="buy.php?id=<?php echo $row['id_produk']; ?>">Buy Now</a>
        </div>
        <?php endwhile; ?>
    </div>

</body>
</html>
