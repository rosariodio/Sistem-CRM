<?php
include "../koneksi.php";
session_start();

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

// Get user ID from URL parameter
$id_user = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Validate ID
if ($id_user <= 0) {
    echo "Invalid user ID.";
    exit();
}

// Fetch history data from the database
$query = "SELECT 
    transaksi_poin_loyalty.id_transaksi, 
    transaksi_poin_loyalty.tgl, 
    transaksi_poin_loyalty.poin_ditukarkan,
    hadiah.nama_hadiah, 
    user.username
FROM transaksi_poin_loyalty
INNER JOIN user ON transaksi_poin_loyalty.user = user.id_user
INNER JOIN hadiah ON transaksi_poin_loyalty.item = hadiah.id_hadiah WHERE transaksi_poin_loyalty.user = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param('i', $id_user);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History Penukaran Poin</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Source Sans Pro', sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            color: #fff;
        }

        .container {
            margin: 20px;
        }

        h2 {
            text-align: center;
            color: #fff; /* White text color */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            color: #333;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th {
            background-color: #F9F7C9;
            color: #B52A34; /* Red color theme */
            padding: 12px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        td {
            background-color: #fafafa;
        }

        a.button {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #B52A34; /* Red color theme */
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin-top: 20px;
        }

        a.button:hover {
            background-color: #D05B57; /* Lighter red on hover */
        }
    </style>
</head>
<body>
<div class="container">
    <h2>History Penukaran Poin</h2>
    <a href="http://localhost/sistem_loyalty/data_user/read.php" class="button">Back</a>
    <table>
        <tr>
            <th>Tanggal Penukaran</th>
            <th>Username</th>
            <th>Hadiah yang Dibeli</th>
            <th>Poin Ditukarkan</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['tgl']) . "</td>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>" . htmlspecialchars($row['nama_hadiah']) . "</td>
                        <td>" . htmlspecialchars($row['poin_ditukarkan']) . " points</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No history found for this user.</td></tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
