<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $query = "INSERT INTO user (username, password, email, role) VALUES ('$username', '$password', '$email', '$role')";
    $result = mysqli_query($koneksi, $query);

    if(!$result){
        echo "Data gagal ditambahkan!";
    }
    else{
        echo "Data berhasil ditambahkan!";
        header("Location: http://localhost/sistem_loyalty/data_user/read.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data User</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap');

        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 70px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            max-width: 600px; /* Updated to make the form wider */
            width: 100%;
            border: 1px solid #e6e6e6;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"], select {
            width: 95%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button[type="submit"], .button {
            padding: 10px 20px;
            background-color: #c0392b;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        button[type="submit"]:hover, .button:hover {
            background-color: #e74c3c;
        }

        .button {
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h1>Tambah Data User</h1>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username">
            <br>
            <label for="password">Password:</label>
            <input type="text" name="password" id="password">
            <br>
            <label for="email">Email:</label>
            <input type="text" name="email" id="email">
            <label for="role">Role:</label>
            <select name="role" id="role">
                <option value="1">Pelanggan</option>
                <option value="2">Admin</option>
            </select>
            <br>
            <br>
            <button type="submit" name="submit">Add</button>
            <a href="http://localhost/sistem_loyalty/data_user/read.php" class="button">Back</a>
        </form>
    </div>
</body>
</html>
