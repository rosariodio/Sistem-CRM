<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data User</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Source Sans Pro', sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            color: #fff;
        }

        .container {
            margin: 20px;
        }

        h2 {
            text-align: center;
            color: #fff; /* White text color */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            color: #333;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th {
            background-color: #F9F7C9;
            color: #B52A34; /* Red color theme */
            padding: 12px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        td {
            background-color: #fafafa;
        }

        a.button {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #B52A34; /* Red color theme */
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            margin: 5px 0;
        }

        a.button:hover {
            background-color: #D05B57; /* Lighter red on hover */
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Data User</h2>

    <a href="http://localhost/sistem_loyalty/data_user/create.php" class="button">Create</a>
    <a href="http://localhost/sistem_loyalty/homePage.php" class="button">Back</a>

    <table>
        <tr>
            <th>Username</th>
            <th>Profile</th>
            <th>History Transaksi Belanja & Poin</th>
            <th>History Penukaran Poin</th>
            <th>Action</th>
        </tr>
        <?php
        $query = "SELECT * FROM user";
        $result = mysqli_query($koneksi, $query);

        if (!$result) {
            echo "query gagal!";
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>
                            <a href='http://localhost/sistem_loyalty/data_user/profile.php?id=" . $row['id_user'] . "' class='button'>Enter</a>
                        </td>
                         <td>
                            <a href='http://localhost/sistem_loyalty/data_user/history_belanja.php?id=" . $row['id_user'] . "' class='button'>Enter</a>
                        </td>
                        <td>
                            <a href='http://localhost/sistem_loyalty/data_user/history_poin.php?id=" . $row['id_user'] . "' class='button'>Enter</a>
                        </td>
                        <td>
                            <a href='http://localhost/sistem_loyalty/data_user/update.php?id=" . $row['id_user'] . "' class='button'>Edit</a> 
                            <a href='http://localhost/sistem_loyalty/data_user/delete.php?id=" . $row['id_user'] . "' class='button'>Delete</a>
                        </td>
                      </tr>";
            }
        }
        ?>
    </table>
</div>
</body>
</html>
