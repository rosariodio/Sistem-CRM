<?php
session_start();
include '../koneksi.php';

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

// Get user ID from URL parameter
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Validate ID
if ($id <= 0) {
    echo "Invalid user ID.";
    exit();
}

// Fetch user profile data from the database
$query = "SELECT username, email, poin_loyalty, membership, password, role FROM user WHERE id_user = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($username, $email, $poin_loyalty, $membership, $password, $role);
    $stmt->fetch();
} else {
    echo "User not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap');

        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .profile-container {
            background-color: #fff;
            padding: 30px;
            border: 1px solid #e6e6e6;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            width: 500px;
            text-align: center;
        }

        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #c0392b;
            margin-bottom: 20px;
        }

        p {
            font-size: 16px;
            color: #333;
            margin: 10px 0;
        }

        a {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #c0392b;
            color: #fff;
            border-radius: 4px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #e74c3c;
        }

        .password-field {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 20px;
        }

        .password-field p {
            margin: 0;
            margin-right: 10px;
            font-weight: 600;
        }

        .password-input {
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
            width: 150px;
        }

        .toggle-password {
            margin-left: 10px;
            cursor: pointer;
            color: #c0392b;
            font-size: 14px;
        }

        .toggle-password:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h1>Profile Information</h1>
        <p><strong>Username:</strong> <?php echo htmlspecialchars($username); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
        <div class="password-field">
            <p><strong>Password:</strong></p>
            <input type="password" id="password" class="password-input" value="<?php echo htmlspecialchars($password); ?>" readonly>
            <span id="togglePassword" class="toggle-password">Show</span>
        </div>
        <p><strong>Role:</strong> <?php echo htmlspecialchars($role); ?></p>
        <p><strong>Poin Loyalty:</strong> <?php echo htmlspecialchars($poin_loyalty); ?></p>
        <p><strong>Membership:</strong> <?php echo htmlspecialchars($membership); ?></p>

        <a href="http://localhost/sistem_loyalty/logout.php">Logout</a>
        <a href="http://localhost/sistem_loyalty/data_user/read.php" class="button">Back</a>
    </div>
    <script>
        const passwordInput = document.getElementById('password');
        const togglePassword = document.getElementById('togglePassword');

        togglePassword.addEventListener('click', function () {
            // Toggle between showing and hiding the password
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);

            // Change the text of the toggle button
            this.textContent = type === 'password' ? 'Show' : 'Hide';
        });
    </script>
</body>
</html>
