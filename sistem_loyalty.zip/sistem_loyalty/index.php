<?php
include 'koneksi.php';

session_start(); // Mulai session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form login
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Query untuk mencari user dengan username dan password yang sesuai
    $query = "SELECT id_user, role FROM user WHERE username=? AND password=?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        // Jika data ditemukan, simpan informasi pengguna dalam session
        $stmt->bind_result($id_user, $role);
        $stmt->fetch();

        $_SESSION['username'] = $username; //session membawa data username
        $_SESSION['id_user'] = $id_user; //session membawa data id user
        $_SESSION['role'] = $role; //session membawa data role

        // Redirect ke halaman utama
        header("Location: http://localhost/sistem_loyalty/homePage.php");
        exit(); // Pastikan untuk menghentikan eksekusi kode setelah melakukan redirect
    } else {
        // Jika data tidak ditemukan, tampilkan pesan error
        echo "<script>
        alert('Username atau password salah.');
        window.location.href = 'http://localhost/sistem_loyalty/index.php';
      </script>";
    }

    $stmt->close();
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap');

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Source Sans Pro', Arial, sans-serif; /* Font similar to Odoo */
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Strong red to orange gradient */
        }

        .container {
            background-color: #ffffff;
            padding: 50px 100px;
            border: 1px solid #d1d1d1;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .container p:first-of-type {
            font-size: 28px;
            font-weight: 600; /* Semi-bold for emphasis */
            color: #c0392b; /* Red primary color */
            margin: 0 0 10px;
        }

        .container p:nth-of-type(2) {
            font-size: 16px;
            font-weight: 400; /* Regular weight for secondary text */
            color: #7f8c8d; /* Subtle grey for description text */
        }

        input {
            width: 120%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #d1d1d1;
            border-radius: 4px;
            font-size: 14px;
            font-family: 'Source Sans Pro', Arial, sans-serif;
        }

        input[type="submit"] {
            background-color: #c0392b; /* Red primary color */
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-family: 'Source Sans Pro', Arial, sans-serif;
        }

        input[type="submit"]:hover {
            background-color: #e74c3c; /* Hover effect */
        }

        #register {
            cursor: pointer;
            color: #c0392b; /* Red primary color */
            font-size: 14px;
            font-weight: 600;
            display: inline-block;
            margin-top: 10px;
        }

        #register:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <p>Login</p>
        <p>Sistem Loyalty</p>
        <form method="POST">
            <label for="username">Username</label><br/>
            <input type="text" name="username" id="username" placeholder="Username" ><br/>
            <label for="password">Password</label><br/>
            <input type="password" name="password" id="password" placeholder="Password"><br/><br/>
            <input type="submit" name="submit" value="Masuk">
            <span id="register">Register Account</span> 
        </form>
    </div>
    <script>
        //forgot password button
        document.getElementById("register").addEventListener("click", function() {
            window.location.href = "http://localhost/sistem_loyalty/register.php";
        });
    </script>
</body>
</html>
