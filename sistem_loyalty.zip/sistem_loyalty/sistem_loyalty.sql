-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2025 at 09:06 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistem_loyalty`
--

-- --------------------------------------------------------

--
-- Table structure for table `hadiah`
--

CREATE TABLE `hadiah` (
  `id_hadiah` int(10) NOT NULL,
  `nama_hadiah` varchar(100) DEFAULT NULL,
  `harga_produk_satuan` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hadiah`
--

INSERT INTO `hadiah` (`id_hadiah`, `nama_hadiah`, `harga_produk_satuan`) VALUES
(1, 'Voucher Diskon 15%', 20),
(2, 'Voucher Diskon 20%', 30),
(3, 'Voucher Gratis Ongkir', 25),
(4, 'Tiket CGV', 50),
(5, 'Tiket ke Transtudio Bandung', 100),
(6, 'DISKON 50%', 60);

-- --------------------------------------------------------

--
-- Table structure for table `hak_akses`
--

CREATE TABLE `hak_akses` (
  `id` int(10) NOT NULL,
  `role_id` int(10) NOT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `fitur` varchar(50) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hak_akses`
--

INSERT INTO `hak_akses` (`id`, `role_id`, `role_name`, `fitur`, `link`) VALUES
(1, 1, 'Pelanggan', 'Profile', 'http://localhost/sistem_loyalty/profile.php'),
(2, 1, 'Pelanggan', 'Product Shop', 'http://localhost/sistem_loyalty/belanja/productShop.php'),
(3, 1, 'Pelanggan', 'Reward Shop', 'http://localhost/sistem_loyalty/tukar_poin/loyaltyShop.php'),
(4, 1, 'Pelanggan', 'Reward Transaction History', 'http://localhost/sistem_loyalty/history_poin_user.php'),
(5, 2, 'Admin', 'Profile', 'http://localhost/sistem_loyalty/profile.php'),
(6, 2, 'Admin', 'User Data Management', 'http://localhost/sistem_loyalty/data_user/read.php'),
(7, 2, 'Admin', 'CRM Page', 'http://localhost/sistem_loyalty/crm/halaman_crm.php'),
(8, 2, 'Admin', 'Shopping Transaction Management', 'http://localhost/sistem_loyalty/data_transaksi_belanja/read.php'),
(9, 2, 'Admin', 'Product Shop & Edit Product', 'http://localhost/sistem_loyalty/belanja/productShop.php'),
(10, 2, 'Admin', 'Reward Shop & Edit Reward', 'http://localhost/sistem_loyalty/tukar_poin/loyaltyShop.php'),
(11, 2, 'Admin', 'Edit Reward', 'http://localhost/sistem_loyalty/data_hadiah/read.php'),
(12, 2, 'Admin', 'Edit Product', 'http://localhost/sistem_loyalty/data_produk/read.php');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(10) NOT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `harga_produk_satuan` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga_produk_satuan`) VALUES
(1, 'Sabun Lifebuoy', 35000),
(2, 'Minyak Goreng Sunco', 30000),
(3, 'Melon', 50000),
(4, 'Anggur Hijau', 45000),
(5, 'Betadine', 20000),
(6, 'Ayam Fillet', 50000),
(7, 'Daging Sapi Giling', 80000),
(8, 'Lobster', 250000),
(14, 'Minyak Goreng Bimoli', 50000),
(15, 'Sarden ABC', 25000),
(16, 'Santan KARA', 25000),
(17, 'Sambal ABC', 30000);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_poin_loyalty`
--

CREATE TABLE `transaksi_poin_loyalty` (
  `id_transaksi` int(10) NOT NULL,
  `tgl` datetime DEFAULT current_timestamp(),
  `user` int(10) NOT NULL,
  `item` int(10) DEFAULT NULL,
  `poin_ditukarkan` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_poin_loyalty`
--

INSERT INTO `transaksi_poin_loyalty` (`id_transaksi`, `tgl`, `user`, `item`, `poin_ditukarkan`) VALUES
(60, '2024-12-09 20:33:16', 1, 1, 20),
(61, '2024-12-09 20:35:44', 1, 5, 100),
(62, '2024-12-09 20:36:58', 2, 1, 20),
(63, '2024-12-09 20:37:01', 2, 1, 20),
(64, '2024-12-09 20:37:35', 3, 5, 100),
(65, '2024-12-09 20:37:37', 3, 4, 50),
(66, '2024-12-09 20:37:41', 3, 6, 60),
(67, '2024-12-09 20:38:05', 4, 2, 30),
(68, '2024-12-09 20:38:34', 5, 3, 25),
(69, '2024-12-09 20:38:39', 5, 4, 50),
(70, '2024-12-09 20:39:26', 16, 1, 20),
(71, '2024-12-09 20:39:27', 16, 2, 30),
(72, '2024-12-09 20:39:55', 18, 2, 30),
(73, '2024-12-09 20:39:56', 18, 2, 30),
(74, '2024-12-09 20:40:11', 19, 5, 100),
(75, '2024-12-17 18:35:23', 19, 1, 20),
(76, '2025-01-13 02:03:45', 4, 1, 20);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_sales`
--

CREATE TABLE `transaksi_sales` (
  `id_transaksi` int(10) NOT NULL,
  `tgl` datetime DEFAULT current_timestamp(),
  `user` int(10) NOT NULL,
  `item` int(10) DEFAULT NULL,
  `qty` int(10) DEFAULT NULL,
  `perolehan_poin` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_sales`
--

INSERT INTO `transaksi_sales` (`id_transaksi`, `tgl`, `user`, `item`, `qty`, `perolehan_poin`) VALUES
(1, '2024-10-21 12:20:03', 1, 1, 5, 10),
(2, '2024-10-21 12:24:21', 2, 7, 5, 40),
(3, '2024-10-21 12:24:21', 3, 6, 3, 10),
(4, '2024-10-21 12:24:21', 4, 3, 6, 30),
(5, '2024-10-21 12:24:21', 5, 4, 8, 30),
(6, '2024-10-21 12:24:21', 5, 1, 2, 0),
(7, '2024-10-21 12:39:10', 3, 7, 20, 160),
(8, '2024-10-21 12:41:52', 3, 8, 5, 120),
(9, '2024-10-21 13:11:44', 1, 14, 10, 50),
(10, '2024-10-21 13:13:01', 1, 15, 17, 40),
(11, '2024-10-21 13:13:51', 5, 3, 15, 70),
(12, '2024-10-21 13:17:40', 1, 16, 5, 10),
(13, '2024-10-21 13:24:09', 6, 3, 2, 10),
(66, '2024-10-25 12:28:15', 16, 7, 12, 90),
(67, '2024-10-25 12:45:05', 18, 5, 30, 60),
(68, '2024-11-06 13:53:53', 19, 8, 4, 100),
(70, '2024-12-14 19:18:52', 1, 8, 5, 120),
(71, '2024-12-14 19:38:29', 1, 8, 10, 250),
(73, '2024-12-14 20:27:52', 2, 7, 10, 80),
(75, '2024-12-15 19:09:09', 4, 8, 10, 250),
(81, '2024-12-17 18:12:37', 1, 8, 5, 120),
(82, '2024-12-17 18:34:19', 19, 6, 4, 20),
(83, '2024-12-17 18:56:13', 22, 7, 5, 40),
(84, '2025-01-13 02:23:22', 4, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `poin_loyalty` int(20) DEFAULT NULL,
  `membership` varchar(50) DEFAULT NULL,
  `role` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `email`, `poin_loyalty`, `membership`, `role`) VALUES
(1, 'abel', '123456', 'rosariodioo28@gmail.com', 600, 'Platinum', 2),
(2, 'darren', '123456', 'darrenchrist2@gmail.com', 120, 'Bronze', 2),
(3, 'owen', '123456', 'richardowzhu@gmail.com', 290, 'Gold', 1),
(4, 'laras', '123456', 'laraste242@gmail.com', 280, 'Silver', 1),
(5, 'lufty', '123456', 'abdillahlufty@gmail.com', 100, 'Bronze', 1),
(6, 'henry', '123456', 'henrykinan2@gmail.com', 10, 'None', 1),
(16, 'mitha', '123456', 'mithadesi30@gmail.com', 90, 'None', 1),
(18, 'agatha', '123456', 'gathachristyy@gmail.com', 60, 'None', 1),
(19, 'max', '123456', 'maximillianalexx@gmail.com', 120, 'Bronze', 1),
(22, 'vallery', '123456', 'vlrrysng@gmail.com', 40, 'None', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hadiah`
--
ALTER TABLE `hadiah`
  ADD PRIMARY KEY (`id_hadiah`);

--
-- Indexes for table `hak_akses`
--
ALTER TABLE `hak_akses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`) USING BTREE;

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `transaksi_poin_loyalty`
--
ALTER TABLE `transaksi_poin_loyalty`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `customer` (`user`),
  ADD KEY `item` (`item`);

--
-- Indexes for table `transaksi_sales`
--
ALTER TABLE `transaksi_sales`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `customer` (`user`),
  ADD KEY `item` (`item`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hadiah`
--
ALTER TABLE `hadiah`
  MODIFY `id_hadiah` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `hak_akses`
--
ALTER TABLE `hak_akses`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `transaksi_poin_loyalty`
--
ALTER TABLE `transaksi_poin_loyalty`
  MODIFY `id_transaksi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `transaksi_sales`
--
ALTER TABLE `transaksi_sales`
  MODIFY `id_transaksi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi_poin_loyalty`
--
ALTER TABLE `transaksi_poin_loyalty`
  ADD CONSTRAINT `transaksi_poin_loyalty_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `transaksi_poin_loyalty_ibfk_2` FOREIGN KEY (`item`) REFERENCES `hadiah` (`id_hadiah`);

--
-- Constraints for table `transaksi_sales`
--
ALTER TABLE `transaksi_sales`
  ADD CONSTRAINT `transaksi_sales_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `transaksi_sales_ibfk_2` FOREIGN KEY (`item`) REFERENCES `produk` (`id_produk`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
