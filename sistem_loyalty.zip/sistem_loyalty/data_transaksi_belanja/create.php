<?php
include "../koneksi.php";
session_start(); // Start session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

// Get user data for dropdown
$query_users = "SELECT * FROM user";
$result_users = mysqli_query($koneksi, $query_users);

// Get product data for dropdown
$query_produk = "SELECT * FROM produk";
$result_produk = mysqli_query($koneksi, $query_produk);

function calculateLoyaltyPoints($koneksi) {
    // Fetch all transactions
    $query_transactions = "SELECT id_transaksi, user, item, qty FROM transaksi_sales";
    $result_transactions = mysqli_query($koneksi, $query_transactions);

    if ($result_transactions && mysqli_num_rows($result_transactions) > 0) {
        while ($transaction = mysqli_fetch_assoc($result_transactions)) {
            $id_transaksi = $transaction['id_transaksi'];
            $id_user = $transaction['user'];
            $id_item = $transaction['item'];
            $qty = $transaction['qty'];

            // Fetch product price
            $query_product = "SELECT harga_produk_satuan FROM produk WHERE id_produk = $id_item";
            $result_product = mysqli_query($koneksi, $query_product);
            if ($result_product && mysqli_num_rows($result_product) > 0) {
                $row_product = mysqli_fetch_assoc($result_product);
                $harga_produk_satuan = $row_product['harga_produk_satuan'];

                // Calculate loyalty points for this transaction
                $total_spending = $harga_produk_satuan * $qty;
                $loyalty_points = floor($total_spending / 100000) * 10;

                // Update the transaction with calculated points
                $update_transaction = "UPDATE transaksi_sales SET perolehan_poin = $loyalty_points WHERE id_transaksi = $id_transaksi";
                mysqli_query($koneksi, $update_transaction);
            }
        }
    }

    // Recalculate total loyalty points for each user
    $query_users = "SELECT id_user FROM user";
    $result_users = mysqli_query($koneksi, $query_users);

    if ($result_users && mysqli_num_rows($result_users) > 0) {
        while ($user = mysqli_fetch_assoc($result_users)) {
            $id_user = $user['id_user'];

            // Sum all loyalty points from transactions for this user
            $query_total_points = "SELECT SUM(perolehan_poin) AS total_points FROM transaksi_sales WHERE user = $id_user";
            $result_total_points = mysqli_query($koneksi, $query_total_points);

            if ($result_total_points && mysqli_num_rows($result_total_points) > 0) {
                $row_total_points = mysqli_fetch_assoc($result_total_points);
                $total_points = $row_total_points['total_points'] ?? 0;

                // Update user's total loyalty points
                $update_user_points = "UPDATE user SET poin_loyalty = $total_points WHERE id_user = $id_user";
                mysqli_query($koneksi, $update_user_points);
            }
        }
    }
}

function updateMembershipLevel($koneksi) {
    // Fetch all users from the database
    $query_users = "SELECT id_user FROM user";
    $result_users = mysqli_query($koneksi, $query_users);

    if ($result_users && mysqli_num_rows($result_users) > 0) {
        while ($user = mysqli_fetch_assoc($result_users)) {
            $id_user = $user['id_user'];

            // Calculate total spending for this user
            $query_transactions = "SELECT SUM(produk.harga_produk_satuan * transaksi_sales.qty) AS total_spending 
                                    FROM transaksi_sales 
                                    JOIN produk ON transaksi_sales.item = produk.id_produk 
                                    WHERE transaksi_sales.user = $id_user";
            $result_transactions = mysqli_query($koneksi, $query_transactions);
            $transaction_data = mysqli_fetch_assoc($result_transactions);
            $total_spending = $transaction_data['total_spending'] ?? 0;

            // Determine membership level based on total spending
            if ($total_spending >= 4000000) {
                $membership_level = 'Platinum';
            } elseif ($total_spending >= 3000000) {
                $membership_level = 'Gold';
            } elseif ($total_spending >= 2000000) {
                $membership_level = 'Silver';
            } elseif ($total_spending >= 1000000) {
                $membership_level = 'Bronze';
            } else {
                $membership_level = 'None';
            }

            // Update user's membership level in the database
            $update_user = "UPDATE user 
                            SET membership = '$membership_level' 
                            WHERE id_user = $id_user";
            mysqli_query($koneksi, $update_user);
        }
    }
}

if(isset($_POST['submit'])){
    $user = $_POST['user'];
    $item = $_POST['produk'];
    $qty = $_POST['qty'];

    $query = "INSERT INTO transaksi_sales (tgl, user, item, qty) VALUES (NOW(), '$user', '$item', '$qty')";
    $result = mysqli_query($koneksi, $query);

    if(!$result){
        echo "Data gagal ditambahkan!";
    }
    else{
        // Call the function to recalculate loyalty points
        calculateLoyaltyPoints($koneksi);
        updateMembershipLevel($koneksi);
        echo "Data berhasil ditambahkan!";
        header("Location: http://localhost/sistem_loyalty/data_transaksi_belanja/read.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi Belanja</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap');

        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 70px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            border: 1px solid #e6e6e6;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"], select {
            width: 95%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button[type="submit"], .button {
            padding: 10px 20px;
            background-color: #c0392b;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        button[type="submit"]:hover, .button:hover {
            background-color: #e74c3c;
        }

        .button {
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h1>Tambah Transaksi Belanja</h1>
        <form method="post">
            <label for="user">User:</label>
            <select name="user" id="user">
                <?php while ($row = mysqli_fetch_assoc($result_users)) { ?>
                    <option value="<?php echo $row['id_user']; ?>"><?php echo $row['username']; ?></option>
                <?php } ?>
            </select>
            <br>

            <label for="produk">Produk:</label>
            <select name="produk" id="produk">
                <?php while ($row = mysqli_fetch_assoc($result_produk)) { ?>
                    <option value="<?php echo $row['id_produk']; ?>"><?php echo $row['nama_produk']; ?></option>
                <?php } ?>
            </select>
            <br>

            <label for="qty">Jumlah:</label>
            <input type="text" name="qty" id="qty">
            <br>

            <button type="submit" name="submit">Tambah</button>
            <a href="http://localhost/sistem_loyalty/data_transaksi_belanja/read.php" class="button">Kembali</a>
        </form>
    </div>
</body>
</html>
