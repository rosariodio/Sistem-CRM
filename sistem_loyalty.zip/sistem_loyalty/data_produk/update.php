<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

$id = $_GET['id'];
$query = "SELECT * FROM produk WHERE id_produk= '$id'";
$result = mysqli_query($koneksi, $query);
if(!$result){
    echo "Query gagal!";
}
else{
    $data = mysqli_fetch_assoc($result);
}
if(isset($_POST["submit"])){
    $nama_produk = $_POST['nama_produk'];
    $harga_produk_satuan = $_POST['harga_produk_satuan'];

    $query = "UPDATE produk SET nama_produk ='$nama_produk', harga_produk_satuan = '$harga_produk_satuan' WHERE id_produk ='$id' ";
    $result = mysqli_query($koneksi, $query);
    if(!$result){
        echo "Data gagal diubah!";
    }
    else{
        echo "Data berhasil diubah!";
        header("Location: http://localhost/sistem_loyalty/data_produk/read.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data Produk</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap');

        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 70px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            border: 1px solid #e6e6e6;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"] {
            width: 95%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button[type="submit"], .button {
            padding: 10px 20px;
            background-color: #c0392b;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        button[type="submit"]:hover, .button:hover {
            background-color: #e74c3c;
        }

        .button {
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h1>Ubah Data Produk</h1>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $data['id_produk']; ?>">
            <label for="nama_produk">Nama Produk:</label>
            <input type="text" name="nama_produk" id="nama_produk" value="<?php echo $data['nama_produk']; ?>">
            <br>
            <label for="harga_produk_satuan">Harga Produk Satuan:</label>
            <input type="text" name="harga_produk_satuan" id="harga_produk_satuan" value="<?php echo $data['harga_produk_satuan']; ?>">
            <br><br>
            <button type="submit" name="submit">Update</button>
            <a href="http://localhost/sistem_loyalty/data_produk/read.php" class="button">Back</a>
        </form>
    </div>
</body>
</html>
