<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

$id = $_SESSION['id_user'];

// Fetch user role
$sql_role = "SELECT * FROM user WHERE id_user = ?";
$stmt_role = $koneksi->prepare($sql_role);
$stmt_role->bind_param("i", $id);
$stmt_role->execute();
$result_role = $stmt_role->get_result();
$user = $result_role->fetch_assoc();
$role_id = $user['role'];
$poin_loyalty = $user['poin_loyalty'];

// Fetch allowed features for the user role
$sql_access = "SELECT link FROM hak_akses WHERE role_id = ?";
$stmt_access = $koneksi->prepare($sql_access);
$stmt_access->bind_param("i", $role_id);
$stmt_access->execute();
$result_access = $stmt_access->get_result();

// Query to retrieve prize data from the 'hadiah' table
$query_hadiah = "SELECT id_hadiah, nama_hadiah, harga_produk_satuan FROM hadiah";
$result_hadiah = $koneksi->query($query_hadiah); // Execute the query

// Check if the query returned any results
if ($result_hadiah->num_rows == 0) {
    echo "No prizes available.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reward Shop</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Source Sans Pro', Arial, sans-serif;
            background: linear-gradient(135deg, #ff4b5c, #ff6f1f); /* Red to orange gradient */
            margin: 0;
            padding: 0;
            color: #fff;
        }

        .container {
            margin: 20px;
        }

        h1, h2, h3 {
            text-align: center;
            color: #fff; /* White color for headings */
        }

        .button-container {
            text-align: center;
            margin: 20px 0;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #c0392b; /* Red color theme */
            color: white;
            border-radius: 5px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #e74c3c; /* Darker red on hover */
        }

        /* Prize List (ul) */
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        ul li {
            background-color: #fff;
            border: 2px solid #c0392b; /* Red border */
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px; /* Vertical spacing */
            text-align: left; /* Align text to the left */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Shadow effect */
            width: 100%; /* Full width for each item */
        }

        ul li h3 {
            color: #c0392b;
            margin: 15px 0;
            font-size: 18px;
            font-weight: bold;
            text-align: left; /* Ensure heading is aligned to the left */
        }

        ul li p {
            color: #555;
            margin: 10px 0;
            text-align: left; /* Ensure paragraph text is aligned to the left */
        }

        ul li a {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #c0392b; /* Red color theme */
            color: white;
            border-radius: 5px;
            font-weight: 600;
            margin-top: 10px;
            transition: background-color 0.3s ease;
            text-align: left; /* Ensure link is aligned to the left */
        }

        ul li a:hover {
            background-color: #e74c3c; /* Darker red on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Reward Shop</h1>
        <h3>Poin Loyalty: <?php echo htmlspecialchars($poin_loyalty); ?></h3>
        <div class="button-container">
            <?php while ($row = $result_access->fetch_assoc()): ?>
                <?php if ($row['link'] === 'http://localhost/sistem_loyalty/data_hadiah/read.php'): ?>
                    <a href='<?php echo $row['link']; ?>' class="button">Edit Reward</a>
                <?php endif; ?>
            <?php endwhile; ?>
            <a href="http://localhost/sistem_loyalty/homePage.php" class="button">Kembali</a>
        </div>
        <ul>
            <?php while ($row = $result_hadiah->fetch_assoc()): ?>
            <li>
                <h3><?php echo $row['nama_hadiah']; ?></h3>
                <p>Price: <?php echo $row['harga_produk_satuan']; ?> points</p>
                <a href='redeem.php?id=<?php echo $row['id_hadiah']; ?>'>Redeem</a>
            </li>
            <?php endwhile; ?>
        </ul>
    </div>
</body>
</html>
